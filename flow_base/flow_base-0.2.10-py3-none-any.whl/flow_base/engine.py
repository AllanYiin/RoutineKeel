"""Task-neutral execution, checkpointing, output ownership and content caches."""
from __future__ import annotations

import dataclasses
from pathlib import Path
from .presentation import Reporter, ACTIVE
from .diagnostics import record_exception, launcher_id

from . import __version__
from .runtime import FlowError, Runtime, atomic_json, digest, read_json, require_space, sha256, event


def merge(base, patch):
    result = dict(base)
    for key, value in patch.items():
        result[key] = merge(result[key], value) if isinstance(value, dict) and isinstance(result.get(key), dict) else value
    return result


@dataclasses.dataclass
class Context:
    runtime: Runtime
    workflow: object
    source: Path
    workdir: Path
    job_id: str
    prepared: dict
    offline: bool = False
    logdir: Path | None = None
    flow_id: str | None = None
    run_id: str | None = None


class Adapter:
    """Public task API 0.2. Override domain behavior; runtime remains unaware of it."""
    handlers = {}

    def configuration(self, overrides):
        raise NotImplementedError

    def plan(self, runtime, workflow, source=None, output=None):
        blocked = []
        if source is not None and not source.is_file():
            blocked.append({'code': 'INPUT_MISSING', 'path': str(source)})
        return {'workflow': workflow.id, 'blocked': blocked, 'actions': [], 'ready_to_prepare': not blocked}

    def prepare(self, runtime, workflow, offline=False):
        return {'ok': True, 'profile': 'core'}

    def verify(self, runtime, workflow):
        return {'ok': True, 'profile': 'core'}

    def pre_run(self, runtime, workflow, source, offline):
        pass

    def inspect_input(self, runtime, workflow, source):
        pass

    def step_settings(self, workflow, handler, prepared):
        return workflow.options.model_dump()

    def profile_key(self, runtime, workflow):
        return None

    def minimum_space(self, workflow):
        return 0

    def job_scoped(self, handler):
        return False

    def publish(self, terminal, output, workflow):
        from .runtime import atomic_copy
        atomic_copy(terminal, output / 'result.bin')
        return {'status': 'complete'}

    def publish_outputs(self, terminal, output, workflow):
        """Categorized contract. Override to deliver docs/scripts as well as artifacts."""
        from .outputs import artifact_directory
        return self.publish(terminal, artifact_directory(output, 'categorized-v1'), workflow)


def plan(runtime, task, workflow, source=None, output=None):
    from .outputs import choose_output, output_layout
    default_output = choose_output(runtime, task, source)
    output = choose_output(runtime, task, source, output)
    adapter = task.load(runtime)
    result = adapter.plan(runtime, workflow, source, output)
    for step in workflow.steps:
        if step.handler not in adapter.handlers:
            result['blocked'].append({'code': 'HANDLER_MISSING', 'handler': step.handler})
    result['ready_to_prepare'] = not result['blocked']
    result.update(task=task.manifest.id, flow_id=task.flow_id, task_version=task.manifest.version)
    result.update(output=str(output) if output else None,
                  output_selection='workflow_default' if output == default_output else 'explicit',
                  output_layout=output_layout(output, task.manifest.output_layout) if output else task.manifest.output_layout)
    return result


def run_demo(runtime, task, output):
    from .outputs import choose_output, artifact_directory, validate_tree, write_delivery_index
    output = choose_output(runtime, task, requested=output)
    validate_tree(output)
    if output.exists() and any(output.iterdir()):
        raise FlowError('OUTPUT_EXISTS', 'Demo output must be empty')
    run_id = runtime.start_run(task.flow_id, 'demonstration_fixture', output)
    logs = runtime.logs / task.flow_id / run_id
    from types import SimpleNamespace
    reporter = Reporter(task.manifest.title + '｜示範資料（非正式處理）', task.flow_id, run_id, logs, 1)
    reporter_token = ACTIVE.set(reporter)
    try:
        reporter.start()
        reporter.enter(SimpleNamespace(id='demo', handler='adapter.demo'), 1, '建立示範資料')
        result = task.load(runtime).demo(runtime, artifact_directory(output, task.manifest.output_layout))
        result.update(flow_id=task.flow_id, run_id=run_id, output=str(output), output_layout=task.manifest.output_layout)
        result['token_usage'] = reporter.usage.finish()
        result['presentation'] = reporter.references()
        runtime.update_run(run_id, 'complete', finished=True)
        atomic_json(output / 'report.json', result)
        write_delivery_index(output, result)
        atomic_json(logs / 'report.json', result)
        reporter.complete('executed')
        reporter.end(result, {'label': '示範結束：未執行正式處理，不能當作驗收證據。'})
        return result
    except BaseException as exc:
        status = 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed'
        code = exc.code if isinstance(exc, FlowError) else type(exc).__name__
        diagnostic = record_exception(exc, logs, flow_id=task.flow_id, run_id=run_id, launch_id=launcher_id(runtime))
        reporter.fail(code, diagnostic['message'], interrupted=isinstance(exc, KeyboardInterrupt), diagnostic=diagnostic)
        runtime.update_run(run_id, status, error=code, finished=True)
        atomic_json(logs / 'failure.json', {'flow_id': task.flow_id, 'run_id': run_id, 'status': status, 'error': code, 'error_details': diagnostic,
                                                'token_usage': reporter.usage.finish(), 'presentation': reporter.references()})
        if isinstance(exc, FlowError):
            exc.details.update(flow_id=task.flow_id, run_id=run_id)
        raise
    finally:
        ACTIVE.reset(reporter_token)


def run_workflow(runtime, task, workflow, source, output=None, *, offline=False, prepared=None):
    from .outputs import choose_output
    output = choose_output(runtime, task, source, output)
    run_id = runtime.start_run(task.flow_id, source, output)
    logs = runtime.logs / task.flow_id / run_id
    logs.mkdir(parents=True, exist_ok=True)
    previous_logs = getattr(runtime, 'run_logdir', None)
    runtime.run_logdir = logs
    atomic_json(logs / 'run.json', {'flow_id': task.flow_id, 'run_id': run_id, 'task': task.manifest.id, 'status': 'starting'})
    reporter = Reporter(task.manifest.title, task.flow_id, run_id, logs, len(workflow.steps))
    reporter_token = ACTIVE.set(reporter)
    try:
        reporter.start()
        report = _run_workflow(runtime, task, workflow, source, output, run_id=run_id, offline=offline, prepared=prepared)
        runtime.update_run(run_id, report.get('status', 'complete'), job_id=report.get('job_id'), finished=True)
        atomic_json(logs / 'run.json', {'flow_id': task.flow_id, 'run_id': run_id, 'job_id': report.get('job_id'), 'status': report.get('status', 'complete')})
        adapter = task.load(runtime)
        summary = adapter.result_summary(report) if hasattr(adapter, 'result_summary') else None
        reporter.end(report, summary)
        return report
    except BaseException as exc:
        status = 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed'
        code = exc.code if isinstance(exc, FlowError) else type(exc).__name__
        diagnostic = record_exception(exc, logs, flow_id=task.flow_id, run_id=run_id,
                                      launch_id=launcher_id(runtime), step=reporter.step_id)
        reporter.fail(code, diagnostic['message'], interrupted=isinstance(exc, KeyboardInterrupt), diagnostic=diagnostic)
        runtime.update_run(run_id, status, error=code, finished=True)
        atomic_json(logs / 'run.json', {'flow_id': task.flow_id, 'run_id': run_id, 'task': task.manifest.id,
                                       'status': status, 'error': code})
        atomic_json(logs / 'failure.json', {'flow_id': task.flow_id, 'run_id': run_id, 'status': status, 'error': code, 'error_details': diagnostic,
                                                'token_usage': reporter.usage.finish(), 'presentation': reporter.references()})
        if isinstance(exc, FlowError):
            exc.details.update(flow_id=task.flow_id, run_id=run_id)
        raise
    finally:
        ACTIVE.reset(reporter_token)
        runtime.run_logdir = previous_logs


def _run_workflow(runtime, task, workflow, source, output, *, run_id, offline=False, prepared=None):
    from .outputs import output_layout, artifact_directory, validate_tree, write_delivery_index
    adapter = task.load(runtime)
    source, output = Path(source).resolve(), Path(output).resolve()
    if not source.is_file():
        raise FlowError('INPUT_MISSING', 'Input must be a regular file', path=str(source))
    if output == source or output in source.parents:
        raise FlowError('OUTPUT_CONFLICT', 'Choose a separate output directory')
    adapter.pre_run(runtime, workflow, source, offline)
    p = plan(runtime, task, workflow, source, output)
    if p['blocked']:
        raise FlowError('PREFLIGHT_BLOCKED', 'Resolve preflight issues', blockers=p['blocked'])
    runtime.initialize()
    input_hash = sha256(source)
    # Relative locations preserve job ownership after moving a whole workspace.
    def location(path):
        try:
            return {'workspace_relative': path.relative_to(runtime.home.parent).as_posix()}
        except ValueError:
            return {'external_absolute': str(path)}
    output_identity = location(output)
    if output.is_relative_to((task.folder / 'outputs').resolve()) and output_layout(output, task.manifest.output_layout) == 'categorized-v1':
        output_identity = {'flow_relative': output.relative_to(task.folder.resolve()).as_posix()}
    job = digest({'flow_id': task.flow_id, 'input': input_hash, 'output': output_identity})[:32]
    runtime.update_run(run_id, 'waiting', job_id=job)
    work = runtime.home / 'jobs' / task.flow_id / job
    logs = runtime.logs / task.flow_id / run_id
    with runtime.lock('output:' + str(output), timeout=1):
        validate_tree(output)
        report_path = output / 'report.json'
        layout = output_layout(output, task.manifest.output_layout)
        if output.exists() and (not output.is_dir() or any(output.iterdir())):
            if not report_path.is_file() or read_json(report_path).get('job_id') != job:
                raise FlowError('OUTPUT_EXISTS', 'Output contains another job; choose an empty directory')
        work.mkdir(parents=True, exist_ok=True)
        logs.mkdir(parents=True, exist_ok=True)
        if hasattr(adapter, 'check_output'):
            adapter.check_output(runtime, workflow, artifact_directory(output, layout))
        output.mkdir(parents=True, exist_ok=True)
        history = []
        atomic_json(report_path, {'job_id': job, 'status': 'preparing', 'runtime': __version__, 'output_layout': layout})
        try:
            runtime.update_run(run_id, 'preparing', job_id=job)
            if prepared is None:
                adapter.prepare(runtime, workflow, offline)
                adapter.inspect_input(runtime, workflow, source)
                prepared = adapter.verify(runtime, workflow)
            ACTIVE.get().environment_ready(prepared)
            snapshot = {'runtime': __version__, 'task': task.manifest.id, 'task_version': task.manifest.version,
                        'flow_id': task.flow_id, 'run_id': run_id,
                        'task_hash': task.fingerprint, 'job_id': job, 'workflow': workflow.model_dump(),
                        'input_hash': input_hash, 'source': location(source), 'prepared': prepared}
            atomic_json(work / 'snapshot.json', snapshot)
            ctx = Context(runtime, workflow, source, work, job, prepared, offline, logs, task.flow_id, run_id)
            runtime.update_run(run_id, 'running', job_id=job)
            artifacts = {}
            for index, step in enumerate(workflow.steps, 1):
                label = adapter.step_title(step) if hasattr(adapter, 'step_title') else step.id
                ACTIVE.get().enter(step, index, label)
                deps = {name: artifacts[name] for name in step.needs}
                key = digest({'runtime_api': '0.2', 'task_hash': task.manifest.sha256,
                              'handler': step.handler, 'parameters': step.parameters,
                              'dependencies': {k: sha256(v) for k, v in deps.items()},
                              'source': input_hash if not deps else None,
                              'settings': adapter.step_settings(workflow, step.handler, prepared),
                              'profile': adapter.profile_key(runtime, workflow),
                              'job': job if adapter.job_scoped(step.handler) else None})
                with runtime.lock('step:' + key, timeout=600):
                    artifact = runtime.cached(key)
                    if artifact and hasattr(adapter, 'artifact_valid') and not adapter.artifact_valid(runtime, step.handler, artifact):
                        artifact = None
                    if artifact:
                        status = 'cached'
                    else:
                        target = runtime.home / 'artifacts' / key / 'result.json'
                        target.parent.mkdir(parents=True, exist_ok=True)
                        atomic_json(logs / 'pending_step.json', {'flow_id': task.flow_id, 'run_id': run_id,
                            'job_id': job, 'step': step.id, 'handler': step.handler,
                            'artifact': target.relative_to(runtime.home).as_posix()})
                        require_space(target, adapter.minimum_space(workflow))
                        artifact = Path(adapter.handlers[step.handler](ctx, step, deps, target)).resolve()
                        if not artifact.is_relative_to(target.parent.resolve()) or not artifact.is_file():
                            raise FlowError('HANDLER_CONTRACT', 'Handler must return a file in its assigned artifact directory')
                        runtime.remember(key, artifact)
                        status = 'executed'
                    artifacts[step.id] = artifact
                    row = {'id': step.id, 'handler': step.handler, 'status': status, 'cache_key': key}
                    history.append(row)
                    ACTIVE.get().complete(status)
                    atomic_json(work / 'progress.json', {'flow_id': task.flow_id, 'run_id': run_id, 'job_id': job, 'steps': history})
                    atomic_json(logs / 'progress.json', {'flow_id': task.flow_id, 'run_id': run_id, 'job_id': job, 'steps': history})
            terminal = artifacts[workflow.steps[-1].id]
            if layout == 'categorized-v1' and hasattr(adapter, 'publish_outputs'):
                report = adapter.publish_outputs(terminal, output, workflow)
            else:
                report = adapter.publish(terminal, artifact_directory(output, layout), workflow)
            report['token_usage'] = ACTIVE.get().usage.finish()
            report['presentation'] = ACTIVE.get().references()
            report.update(flow_id=task.flow_id, run_id=run_id, job_id=job, runtime=__version__, steps=history, snapshot=snapshot, output=str(output), output_layout=layout)
            atomic_json(report_path, report)
            write_delivery_index(output, report)
            atomic_json(logs / 'report.json', report)
            return report
        except BaseException as exc:
            diagnostic = record_exception(exc, logs, flow_id=task.flow_id, run_id=run_id, job_id=job,
                                          launch_id=launcher_id(runtime), step=ACTIVE.get().step_id)
            failure = {'job_id': job, 'status': 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed',
                       'flow_id': task.flow_id, 'run_id': run_id, 'output_layout': layout,
                       'error': exc.code if isinstance(exc, FlowError) else type(exc).__name__, 'error_details': diagnostic, 'steps': history,
                       'token_usage': ACTIVE.get().usage.finish(), 'presentation': ACTIVE.get().references()}
            atomic_json(report_path, failure)
            atomic_json(logs / 'report.json', failure)
            raise
